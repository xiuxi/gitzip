# Get Token Steps.

### Step 1

![Image of Step1](https://raw.githubusercontent.com/KinoLien/gitzip/gh-pages/images/get-token-step1.png)

### Step 2

![Image of Step2](https://raw.githubusercontent.com/KinoLien/gitzip/gh-pages/images/get-token-step2.png)

### Step 3

The browser would trigger download, and then save it.

### Step 4

Open the file:  
![Image of Step4](https://raw.githubusercontent.com/KinoLien/gitzip/gh-pages/images/get-token-step4.png)

### Step 5

![Image of Step5](https://raw.githubusercontent.com/KinoLien/gitzip/gh-pages/images/get-token-step5.png)

### Finally

And now, you can continue search or download files/sub-folders. Have fun :)
